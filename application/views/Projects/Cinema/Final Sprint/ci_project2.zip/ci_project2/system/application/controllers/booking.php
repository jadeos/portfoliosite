<?php

/**
 * Created by PhpStorm.
 * Date: 09/11/2015
 * Time: 12:08
 */
class booking extends Controller
{
    public function index()
    {

        $this->load->view('booking');
    }

    }